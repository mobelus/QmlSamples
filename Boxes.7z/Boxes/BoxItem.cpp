#include "BoxItem.h"

BoxItem::BoxItem(const QString &text, const QColor &color)
	: _text(text)
	, _color(color)
{
}

QString BoxItem::text() const
{
	return _text;
}

QColor BoxItem::color() const
{
	return _color;
}

void BoxItem::setText(const QString &text)
{
	_text = text;
}

void BoxItem::setColor(const QColor &color)
{
	_color = color;
}
