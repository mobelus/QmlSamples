#ifndef BOXITEMMODEL_H
#define BOXITEMMODEL_H

#include "BoxItem.h"

#include <QAbstractListModel>
#include <QJsonObject>

class BoxItemModel : public QAbstractListModel
{
	Q_OBJECT
	Q_PROPERTY(int count READ count NOTIFY countChanged)
public:
	enum BoxItemRoles {
		TextRole = Qt::UserRole + 1,
		ColorRole
	};

	explicit BoxItemModel(QObject *parent = nullptr);

	// Добавить элементв в конец списка
	// QJsonObject делает передачу параметров как в стандартной модели списка QML
	Q_INVOKABLE void append(QJsonObject object);
	// Удалить один элемен с заданным индексом
	Q_INVOKABLE void remove(int index);
	// Удалить все элементы
	Q_INVOKABLE void clear();
	// Задать текст элемента
	Q_INVOKABLE void setText(int index, const QString &text);

	// Добавлегие нового элемента
	void addBoxItem(const BoxItem &item);

	// Число строк в модели
	int rowCount(const QModelIndex &parent = QModelIndex()) const;

	// Доступ к данным
	QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;

	// Установка данных
	bool setData(const QModelIndex &index, const QVariant &value, int role);

	// Число элементов в модели
	int count() const;

	// Установка имени файла для сохранения данных
	void setFileName(const QString &fileName);

signals:
	// Сигнал, что количество изменилось
	void countChanged();

public slots:
	// Сохранить в файл
	void store();

	// Загрузить из файла
	void restore();


protected:
	QHash<int, QByteArray> roleNames() const;

private:
	QList<BoxItem> _items;
	QString _fileName;
};

#endif // BOXITEMMODEL_H
