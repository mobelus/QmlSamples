#ifndef BOXITEM_H
#define BOXITEM_H

#include <QString>
#include <QColor>

class BoxItem
{
public:
	BoxItem(const QString &text, const QColor &color);

	QString text() const;
	QColor color() const;


	void setText(const QString &text);
	void setColor(const QColor &color);

private:
	QString _text;
	QColor _color;
};

#endif // BOXITEM_H
