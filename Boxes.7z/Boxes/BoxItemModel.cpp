#include "BoxItemModel.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QFile>
#include <QDebug>

BoxItemModel::BoxItemModel(QObject *parent)
	: QAbstractListModel(parent)
	, _fileName("sync.txt") // Имя файла для сохранения данных по умолчанию
{
	restore();

	// Сохранаять при каждом изменении количества
	connect(this, SIGNAL(countChanged()), this, SLOT(store()));
	connect(this, SIGNAL(dataChanged(const QModelIndex&, const QModelIndex&, const QVector<int> &)), this, SLOT(store()));
}

void BoxItemModel::append(QJsonObject object)
{
	if (object.contains("modelText") && object.contains("modelColor"))
		addBoxItem(BoxItem(object["modelText"].toString(), QColor(object["modelColor"].toString())));
}

void BoxItemModel::remove(int index)
{
	if (index < 0)
		return;
	if (index > rowCount() - 1)
		return;

	beginRemoveRows(QModelIndex(), index, index);
	_items.removeAt(index);
	endRemoveRows();
	emit countChanged();
}

void BoxItemModel::clear()
{
	if (_items.count() <= 0)
		return;

	beginRemoveRows(QModelIndex(), 0, rowCount() -1);
	_items.clear();
	endRemoveRows();

	emit countChanged();
}

void BoxItemModel::setText(int index, const QString &text)
{
	setData(createIndex(index, 0), text, TextRole);
}

void BoxItemModel::addBoxItem(const BoxItem &item)
{
	beginInsertRows(QModelIndex(), rowCount(), rowCount());
	_items << item;
	endInsertRows();
	emit countChanged();
}

int BoxItemModel::rowCount(const QModelIndex & parent) const
{
	Q_UNUSED(parent);
	return _items.count();
}

QVariant BoxItemModel::data(const QModelIndex & index, int role) const
{
	if (index.row() < 0 || index.row() >= _items.count())
		return QVariant();

	const BoxItem &item = _items[index.row()];
	if (role == TextRole)
		return item.text();
	else if (role == ColorRole)
		return item.color();
	return QVariant();
}

bool BoxItemModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
	if (index.row() < 0 || index.row() >= _items.count())
		return false;

	BoxItem &item = _items[index.row()];

	if (role == TextRole)
	{
		item.setText(value.toString());
		emit dataChanged(index, index);
		return true;
	}
	else if (role == ColorRole)
	{
		item.setColor(value.value<QColor>());
		emit dataChanged(index, index);
		return true;
	}

	return false;
}

int BoxItemModel::count() const
{
	return _items.count();
}

void BoxItemModel::setFileName(const QString &fileName)
{
	_fileName = fileName;
	restore();
}

void BoxItemModel::store()
{
	// Сохранение в Json формат
	QJsonArray array;
	for (int i = 0; i < _items.count(); i ++)
	{
		auto item = _items[i];
		QJsonObject obj;
		obj.insert("text", QJsonValue(item.text()));
		obj.insert("color", QJsonValue(item.color().name()));
		array.append(obj);
	}

	QJsonDocument doc;
	doc.setArray(array);

	QFile file(_fileName);
	if (file.open(QFile::Text | QFile::WriteOnly))
	{
		file.write(doc.toJson());
		file.close();
	}
}

void BoxItemModel::restore()
{
	// Загрузка из Json формата
	QFile file(_fileName);
	if (file.open(QFile::Text | QFile::ReadOnly))
	{
		auto doc = QJsonDocument::fromJson(file.readAll());
		file.close();

		clear();

		auto array = doc.array();
		for (int i = 0; i < array.count(); i ++)
		{
			QJsonValue value = array[i];
			if (value.isObject())
			{
				QJsonObject obj = value.toObject();
				addBoxItem(BoxItem(obj["text"].toString(), QColor(obj["color"].toString())));
			}
		}
	}
}

QHash<int, QByteArray> BoxItemModel::roleNames() const
{
	// Имена используемые в QMLs
	QHash<int, QByteArray> roles;
	roles[TextRole] = "modelText";
	roles[ColorRole] = "modelColor";
	return roles;
}

