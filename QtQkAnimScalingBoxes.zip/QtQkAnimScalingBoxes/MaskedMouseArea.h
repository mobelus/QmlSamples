#ifndef QMLSCENE_MASKEDMOUSEAREA_H
#define QMLSCENE_MASKEDMOUSEAREA_H

#include <QImage>
#include <QQuickItem>
#include <QQuickItemGrabResult>
#include <QQuickView>
#include <QMutex>

//#include "QmlScene_global.h"

//namespace QmlScene
//{
class MaskedMouseArea : public QQuickItem
{
	Q_OBJECT
	Q_PROPERTY(bool pressed READ isPressed NOTIFY pressedChanged)
	Q_PROPERTY(bool containsMouse READ containsMouse NOTIFY containsMouseChanged)
	Q_PROPERTY(QQuickItem * maskSourceObject READ maskSourceObject WRITE setMaskSourceObject NOTIFY maskSourceObjectChanged)
	Q_PROPERTY(qreal alphaThreshold READ alphaThreshold WRITE setAlphaThreshold NOTIFY alphaThresholdChanged)
	Q_PROPERTY(qreal mouseX READ mouseX)
	Q_PROPERTY(qreal mouseY READ mouseY)
	Q_PROPERTY(Qt::MouseButtons pressedButtons READ pressedButtons)

public:
	/**
		 * @brief Register class for QML (import QmlScene 1.0)
		 */
	static void qmlInit(const char *uri = "QmlScene");

	MaskedMouseArea(QQuickItem * parent = nullptr);
	virtual ~MaskedMouseArea();

	bool contains(const QPointF &point) const;

	bool isPressed() const { return _pressed; }
	bool containsMouse() const { return _containsMouse; }

	QQuickItem * maskSourceObject() const { return _maskSourceObject; }
	void setMaskSourceObject(QQuickItem *maskSourceObject);

	qreal alphaThreshold() const { return _alphaThreshold; }
	void setAlphaThreshold(qreal threshold);

	qreal mouseX() const { return _pressPoint.x(); }
	qreal mouseY() const { return _pressPoint.y(); }

	Qt::MouseButtons pressedButtons() const { return _pressedButtons; }

	Q_INVOKABLE void regrabMask();

public slots:
	void imageReady();

signals:
	void pressed();
	void released();
	void clicked();
	void canceled();
	void pressedChanged();
	void maskSourceObjectChanged();
	void containsMouseChanged();
	void alphaThresholdChanged();

protected:
	void setPressed(bool pressed);
	void setContainsMouse(bool containsMouse);
	void mousePressEvent(QMouseEvent * event);
	void mouseReleaseEvent(QMouseEvent * event);
	void hoverEnterEvent(QHoverEvent * event);
	void hoverLeaveEvent(QHoverEvent * event);
	void mouseUngrabEvent();

private:
	QQuickItem * _maskSourceObject;

	mutable QSharedPointer<QQuickItemGrabResult> _grabResult;
	mutable QImage _maskImage;
	mutable QMutex _mutex;

	bool _pressed;
	QPointF _pressPoint;
	qreal _alphaThreshold;
	bool _containsMouse;
	Qt::MouseButtons _pressedButtons;
};

//}

#endif // QMLSCENE_MASKEDMOUSEAREA_H
