#include "MaskedMouseArea.h"

#include <QStyleHints>
#include <QGuiApplication>
#include <QQuickWindow>
#include <QtMath>

//namespace QmlScene
//{



void MaskedMouseArea::qmlInit(const char *uri)
{
	qmlRegisterType<MaskedMouseArea>(uri, 1, 0, "MaskedMouseArea");
}



MaskedMouseArea::MaskedMouseArea(QQuickItem * parent)
	: QQuickItem(parent)
	, _maskSourceObject(nullptr)
	, _pressed(false)
	, _alphaThreshold(0.0)
	, _containsMouse(false)
	, _pressedButtons(Qt::NoButton)
{
	setAcceptHoverEvents(true);
	setAcceptedMouseButtons(Qt::LeftButton | Qt::RightButton);
}



MaskedMouseArea::~MaskedMouseArea()
{
}



void MaskedMouseArea::setPressed(bool pressed)
{
	if (_pressed != pressed) {
		_pressed = pressed;
		emit pressedChanged();
	}
}



void MaskedMouseArea::setContainsMouse(bool containsMouse)
{
	if (_containsMouse != containsMouse) {
		_containsMouse = containsMouse;
		emit containsMouseChanged();
	}
}



void MaskedMouseArea::setMaskSourceObject(QQuickItem *maskSourceObject)
{
	if (_maskSourceObject != maskSourceObject)
	{
		_maskSourceObject = maskSourceObject;
		emit maskSourceObjectChanged();
	}
}



void MaskedMouseArea::setAlphaThreshold(qreal threshold)
{
	static const qreal LIMIT = 0.001;
	if (qAbs(_alphaThreshold - threshold) < LIMIT) {
		_alphaThreshold = threshold;
		emit alphaThresholdChanged();
	}
}



void MaskedMouseArea::regrabMask()
{
	_mutex.lock();
	_maskImage = QImage();
	_mutex.unlock();
}



void MaskedMouseArea::imageReady()
{
	_mutex.lock();

	if (!_grabResult.isNull())
	{
		_maskImage = _grabResult->image();
		//_maskImage.save(this->parentItem()->objectName() + ".png");
	}

	_mutex.unlock();
}



bool MaskedMouseArea::contains(const QPointF &point) const
{
	bool result = false;

	_mutex.lock();

	if (_maskImage.isNull())
	{
		if (_grabResult.isNull() && (_maskSourceObject != nullptr) && isComponentComplete()) {
			_grabResult = _maskSourceObject->grabToImage(
						QSize(static_cast<int>(_maskSourceObject->width()),
							  static_cast<int>(_maskSourceObject->height())));
			if (!_grabResult.isNull())
			{
				connect(_grabResult.data(), SIGNAL(ready()), this, SLOT(imageReady()));
			}
		}
	}
	else
	{
		if (!_grabResult.isNull())
		{
			disconnect(_grabResult.data(), SIGNAL(ready()), this, SLOT(imageReady()));
			_grabResult.clear();
		}

		if (QQuickItem::contains(point))
		{
			QPoint p = point.toPoint();

			if (!(p.x() < 0 || p.x() >= _maskImage.width() ||
				  p.y() < 0 || p.y() >= _maskImage.height()))
			{
				qreal r = qBound<int>(0, static_cast<int>(_alphaThreshold * 255), 255);
				result = qAlpha(_maskImage.pixel(p)) > r;
			}
		}
	}

	_mutex.unlock();

	return result;
}



void MaskedMouseArea::mousePressEvent(QMouseEvent * event)
{
	setPressed(true);
	_pressPoint = event->pos();
	_pressedButtons = event->buttons();
	emit pressed();
}



void MaskedMouseArea::mouseReleaseEvent(QMouseEvent * event)
{
	setPressed(false);
	emit released();

	const int threshold = qApp->styleHints()->startDragDistance();
	const bool isClick = (threshold >= qAbs(event->x() - _pressPoint.x()) &&
						  threshold >= qAbs(event->y() - _pressPoint.y()));

	if (isClick)
		emit clicked();
}



void MaskedMouseArea::mouseUngrabEvent()
{
	setPressed(false);
	emit canceled();
}



void MaskedMouseArea::hoverEnterEvent(QHoverEvent * event)
{
	Q_UNUSED(event);
	setContainsMouse(true);
}



void MaskedMouseArea::hoverLeaveEvent(QHoverEvent * event)
{
	Q_UNUSED(event);
	setContainsMouse(false);
}



//}
