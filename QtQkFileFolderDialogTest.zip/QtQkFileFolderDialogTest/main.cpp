#include <QApplication>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QtQml>

#include <QFileSystemModel>
#include <QDateTime>
#include <QDesktopServices>
#include <QUrl>

#include "DisplayFileSystemModel.h"


int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
/*
    QFileSystemModel fileSystemModel;
    fileSystemModel.setRootPath("C:/");
    //QFileSystemModel *fsm = new DisplayFileSystemModel(&engine);
    fileSystemModel.setRootPath(QDir::homePath());
    fileSystemModel.setResolveSymlinks(true);
    engine.rootContext()->setContextProperty("fileSystemModel", &fileSystemModel);
    engine.rootContext()->setContextProperty("rootPathIndex", fileSystemModel.index( fileSystemModel.rootPath()) );
*/

    qmlRegisterUncreatableType<DisplayFileSystemModel>("io.qt.examples.quick.controls.filesystembrowser", 1, 0,
                                                       "FileSystemModel", "Cannot create a FileSystemModel instance.");
    QFileSystemModel *fsm = new DisplayFileSystemModel(&engine);
	fsm->setRootPath("C:/");

	QFileInfoList drivers = QDir::drives();
	QStringList driversStr;
	for(auto dr : drivers)
		driversStr.append( dr.absolutePath() );

	//fsm->setRootPath( QDir::rootPath() /*QDir::homePath()*/ );
	//fsm->setResolveSymlinks(true);
    engine.rootContext()->setContextProperty("fileSystemModel", fsm);
    engine.rootContext()->setContextProperty("rootPathIndex", fsm->index(fsm->rootPath()));

    engine.load(QUrl(QLatin1String("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}

//#include "main.moc"
